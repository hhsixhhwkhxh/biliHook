package hhsixhhwkhxh.xposed.bilihook;
import android.widget.ArrayAdapter;
import android.content.Context;
import java.util.List;
import android.view.View;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.widget.TextView;
import android.widget.Switch;
import android.widget.CompoundButton;
import android.content.SharedPreferences;
import android.widget.LinearLayout;
import android.graphics.Color;
import android.view.Gravity;

public class FunctionAdapter extends ArrayAdapter<ListItem> {
    
    public FunctionAdapter(Context context, List<ListItem> items) {
        super(context, 0, items);
    }

    
    @Override
    public View getView(final int position, View convertView,  ViewGroup parent) {
        final ListItem item = getItem(position);

        if (convertView == null) {
            
            convertView = item.getView(getContext());
            /*if(function.getExtraView()!=null){
                ((LinearLayout)convertView).addView(function.getExtraView());
            }*/
        }

        item.initView(getContext(),convertView);

        return convertView;
    }
    
}
