package hhsixhhwkhxh.xposed.bilihook;

public interface FunctionOnClickListener {
    
    public void onClick();
    
}
