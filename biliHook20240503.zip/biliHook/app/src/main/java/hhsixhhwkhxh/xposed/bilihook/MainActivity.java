package hhsixhhwkhxh.xposed.bilihook;
 
import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;
import java.util.List;
import java.util.ArrayList;
import android.widget.AdapterView;
import android.view.View;
import android.content.SharedPreferences;
import android.content.Context;
import android.widget.Toast;
import java.io.File;
import java.io.IOException;

public class MainActivity extends Activity {

    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        
    }
}
