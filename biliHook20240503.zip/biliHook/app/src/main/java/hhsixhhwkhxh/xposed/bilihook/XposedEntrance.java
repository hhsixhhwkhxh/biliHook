package hhsixhhwkhxh.xposed.bilihook;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.widget.ListView;
import android.widget.RelativeLayout;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import android.os.Bundle;
import de.robv.android.xposed.XC_MethodHook;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.content.Intent;
import android.content.Context;
import android.widget.EditText;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.Toast;
import android.widget.TextView;
import android.widget.LinearLayout;
import java.util.HashMap;
import java.lang.reflect.Parameter;
import java.lang.reflect.Modifier;
import java.lang.reflect.Constructor;

public class XposedEntrance implements IXposedHookLoadPackage {

    private static final String TargetPackageName = "tv.danmaku.bili";
    public static final String ModuleSettingsActivityName = "com.bilibili.lib.dblconfig.DblConfigActivity";

    private Activity MainActivityV2=null;
    public static int contrastColor=Color.BLACK;
    private ListView listView;
    private List<ListItem> ItemsList;
    SharedPreferences sharedPreferences=null;
    
   
    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

    
        if(!lpparam.packageName.equals(TargetPackageName)){return;}
        
        XposedHelpers.findAndHookMethod("tv.danmaku.bili.MainActivityV2", lpparam.classLoader, "onCreate",
            Bundle.class, new XC_MethodHook() {
                
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    XposedBridge.log("tv.danmaku.bili.MainActivityV2.onCreate()");
                    MainActivityV2 = (Activity) param.thisObject;
                    
                    
                    try{
                        RemoveNavigationBarSign(lpparam);

                        ManageHomePagePush(lpparam);

                        ManageVideoDetailPagePush(lpparam);
                        RemoveVideoDetailPageAD(lpparam);

                        //getBLogMessage(lpparam);
                        //testFunction(lpparam);
                    }catch(Exception e){
                        XposedBridge.log(e);
                    }
                }
            });
        
        
        //添加设置按钮
        //Ltv/danmaku/bili/ui/main2/mine/HomeUserCenterFragment;->onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
        XposedHelpers.findAndHookMethod("tv.danmaku.bili.ui.main2.mine.HomeUserCenterFragment",lpparam.classLoader,"onCreateView",LayoutInflater.class,ViewGroup.class,Bundle.class,new XC_MethodHook(){
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    FrameLayout frameLayout = (FrameLayout) param.getResult();
                    ViewGroup MultipleThemeImageView = frameLayout.findViewById(getViewID("mine_top_view"));
                    
                    View NickNameLayout = frameLayout.findViewById(getViewID("nick_name_layout"));
                    //log(NickNameLayout);
                    NickNameLayout.setVisibility(View.INVISIBLE);
                    
                    Button button = new Button(MainActivityV2);
                    button.setText("biliHook设置");
                    button.setTextColor(Color.BLACK);
                    
                    button.setOnClickListener(new OnClickListener(){
                            @Override
                            public void onClick(View p1) {
                                XposedBridge.log("OnClickListener");
                                Intent intent = new Intent(MainActivityV2,XposedHelpers.findClass(ModuleSettingsActivityName,lpparam.classLoader));
                                intent.putExtra("hook",true);
                                MainActivityV2.startActivity(intent);
                                
                                //NeedHandleSettingsActivityOnCreate =true;
                                
                                //以下几个都有做设置Activity的能力
                                //Lcom/bilibili/ad/adview/download/ADDownloadManagerActivity;->onCreate(Landroid/os/Bundle;)V
                                //Lcom/bilibili/adgame/AdGameDetailActivity;->onCreate(Landroid/os/Bundle;)V
                                //Lcom/bilibili/app/authorspace/ui/nft/ui/activity/NftAggregationActivity;->onCreate(Landroid/os/Bundle;)V
                                //Lcom/bilibili/app/authorspace/ui/nft/ui/activity/SpaceNftOBPActivity;->onCreate(Landroid/os/Bundle;)V
                                
                                //Lcom/bilibili/lib/dblconfig/DblConfigActivity;->onCreate(Landroid/os/Bundle;)V
                                XposedHelpers.findAndHookMethod(ModuleSettingsActivityName,lpparam.classLoader,"onCreate",Bundle.class,new XC_MethodHook(){
                                        @Override
                                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                                            param.args[0]=new Bundle();
                                        }
                                        @Override
                                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                                            //log("after onCreate");
                                            Activity activity = (Activity)param.thisObject;
                                            if(activity.getIntent().getBooleanExtra("hook",false)){
                                                initSettingActivity(lpparam,activity);
                                            }
                                            //XposedHelpers.findAndHookMethod("com.bilibili.studio.uperbase.router.b",lpparam.classLoader,"a",Context.class,new XC_MethodHook(){});
                                            //XposedHelpers.findAndHookMethod("android.app.Activity",lpparam.classLoader,"finish",new XC_MethodHook(){});
                                        }});
                                        }
                        });
                    MultipleThemeImageView.addView(button);
                    
                }
        });
        
        
        //sharedPreferences = MainActivityV2.getSharedPreferences("FunctionPrefs", Context.MODE_PRIVATE);
        //实现功能
        /*try{
            RemoveNavigationBarSign(lpparam);
            
            ManageHomePagePush(lpparam);
            
            ManageVideoDetailPagePush(lpparam);
            RemoveVideoDetailPageAD(lpparam);
            
            getBLogMessage(lpparam);
            testFunction(lpparam);
        }catch(Exception e){
            XposedBridge.log(e);
        }
        
        */
        
      
    }
    
    public void initSettingActivity(final XC_LoadPackage.LoadPackageParam lpparam,final Activity activity){
        
        RelativeLayout layout = new RelativeLayout(activity);
        listView = new ListView(activity);
        listView.setId(View.generateViewId());
        //listView.setBackgroundColor(Color.WHITE);
        
        ColorDrawable background = (ColorDrawable) activity.getWindow().getDecorView().getRootView().getBackground();
        
        
        // 假设底色为color值
        int backgroundColor = background.getColor(); 

        // 计算底色的亮度
        double brightness = 0.299 * Color.red(backgroundColor) + 0.587 * Color.green(backgroundColor) + 0.114 * Color.blue(backgroundColor);

        // 选择一个对比度高的颜色
        
        if (brightness < 128) {
            contrastColor = Color.WHITE;  // 如果底色亮度较暗，选择白色
        } else {
            contrastColor = Color.BLACK;  // 如果底色亮度较亮，选择黑色
        }
        
        
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
        listView.setLayoutParams(params);

        //layout.addView(toolbar);
        layout.addView(listView);
        activity.setContentView(layout);
        
        sharedPreferences = activity.getSharedPreferences("FunctionPrefs", Context.MODE_PRIVATE);
        SwitchFunction.sharedPreferences=sharedPreferences;
        
        ItemsList = new ArrayList<>();
        ItemsList.add(new GroupTitle("biliHook设置"));
        ItemsList.add(new GroupTitle("开关设置请重启b站"));
        ItemsList.add(new GroupTitle("主页导航栏简化",true));
        ItemsList.add(new SwitchFunction("去除主页+号", "最简单的一集", "HomePageNavigationBarRemovePlusSign"));
        ItemsList.add(new SwitchFunction("去除主页会员购", "会员go", "HomePageNavigationBarRemoveVIPShopSign"));
        //ItemsList.add(new Function("显示隐藏评论", "代码来自\"哔哩发评反诈\"", "ShowInvisibleComment"));
        ItemsList.add(new GroupTitle("主页推送",true));
        ItemsList.add(new SwitchFunction("过滤横幅", "宽身位的卡片", "HomePagePushFilterateBanner"));
        ItemsList.add(new SwitchFunction("过滤广告", "尚未完善", "HomePagePushFilterateAD"));
        ItemsList.add(new SwitchFunction("竖屏视频转横屏", "去抖化", "HomePagePushTransformVerticalVideo"));
        ItemsList.add(new SwitchFunction("去\"x万点赞\"", "这样所有视频都能看见up主名字", "HomePagePushRemoveVideoLikeCount"));
        ItemsList.add(new GroupTitle("视频详情页简化",true));
        ItemsList.add(new SwitchFunction("去x万点赞", "同上", "VideoDetailPagePushRemoveVideoLikeCount"));
        ItemsList.add(new SwitchFunction("界面过滤广告", "up主推荐?大喇叭评论区黄条广播?(未完善)", "VideoDetailPageRemoveAD"));
        ItemsList.add(new SwitchFunction("推送过滤非AV", "一刀切直播游戏等等特殊推送", "VideoDetailPagePushFilterateNotAV"));
        ItemsList.add(new GroupTitle("实验性功能",true));
        ItemsList.add(new ButtonFunction("任意门","跳转到任意注册的Activity","AnywhereDoor",new FunctionOnClickListener(){
            public void onClick(){
                final EditText ClassNameEditText = new EditText(activity);
                AlertDialog dialog = new AlertDialog.Builder(activity)
                    .setTitle("Activity的全限定类名")
                    .setView(ClassNameEditText)
                    .setPositiveButton("确定", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dia, int which) {
                            try{
                                
                                activity.startActivity(new Intent(activity,XposedHelpers.findClass(ClassNameEditText.getText().toString(),lpparam.classLoader)));
                            }catch(Exception e){
                                Toast.makeText(activity, "错误:"+e, Toast.LENGTH_LONG).show();
                            }
                        }
                    })
                    .setNegativeButton("取消", null)
                    .create();
                dialog.show();
            }
        }));
        
        FunctionAdapter adapter = new FunctionAdapter(activity, ItemsList);
        listView.setAdapter(adapter);
        
        
    }

    
    
    public void log(Object content){
        if(true){return;}
        if(content==null){content="obj为空";}
        XposedBridge.log(content.toString());
    }
    
    //第一个功能 去除导航栏加号
    public void RemoveNavigationBarSign(final XC_LoadPackage.LoadPackageParam lpparam) throws Exception{
        //Lcom/bilibili/lib/homepage/widget/TabHost;->G(ILandroid/view/View;)V
        //注意这个方法名字被混淆 不同版本名字可能不一样 所以我们先筛出来这个Method对象 再hook
        //导航栏5个标签(首页 动态 +号 会员购 我的)都会走这个方法设置布局 所以以下代码会执行五次 注意判断标签种类

        Method TabSetMethod = selectMethod(XposedHelpers.findClass( "com.bilibili.lib.homepage.widget.TabHost",lpparam.classLoader),void.class,int.class,View.class);
        if(TabSetMethod!=null){
            XposedBridge.hookMethod(TabSetMethod,new XC_MethodHook(){
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        //XposedBridge.log("TabSetMethod 执行");
                        //if(!sharedPreferences.getBoolean("HomePageNavigationBarRemovePlusSign",false)){return;}
                        if(!CheckSharedPreferences()){return;}
                        
                        View baseView = (View) param.args[1];
                        
                        TextView textview = baseView.findViewById(getViewID("tab_text"));
                        
                        //textview.getText()的结果5次分别是 "首页" "动态" "" "会员购" "我的"
                        if(sharedPreferences.getBoolean("HomePageNavigationBarRemovePlusSign",false)&&textview.getText().equals("")){
                            //这里采用较为委婉的方式隐藏布局 其实直接setVisibility应该也没问题
                            baseView.setLayoutParams(new LinearLayout.LayoutParams(0,0));
                        }
                        if(sharedPreferences.getBoolean("HomePageNavigationBarRemoveVIPShopSign",false)&&textview.getText().equals("会员购")){
                            
                            baseView.setLayoutParams(new LinearLayout.LayoutParams(0,0));
                        }
                    }
                });
        }else{
            XposedBridge.log("错误 TabSetMethod未找到");
        }
    }
    
    
    
    public void ManageHomePagePush(final XC_LoadPackage.LoadPackageParam lpparam) throws Exception{
        //com.bilibili.pegasus.promo.index.IndexFeedFragmentV2.Mu(List);
        //com.bilibili.pegasus.api.modelv2
        //com.bilibili.pegasus.promo.BasePromoFragment.Ys()
        //Lcom/bilibili/pegasus/promo/index/IndexFeedFragmentV2$mIndexCallback$1;->onDataSuccess(Ljava/lang/Object;)V
        XposedHelpers.findAndHookMethod("com.bilibili.pegasus.promo.index.IndexFeedFragmentV2$mIndexCallback$1",lpparam.classLoader,"onDataSuccess",Object.class,new XC_MethodHook(){
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    Object PegasusFeedResponse = param.args[0];
                    //log(param.args[0]);
                    Field ItemField = XposedHelpers.findField(XposedHelpers.findClass("com.bilibili.pegasus.api.modelv2.PegasusFeedResponse",lpparam.classLoader),"items");
                    List list = (List) ItemField.get(PegasusFeedResponse);
                    if(!CheckSharedPreferences()){return;}
                    if(list==null||list.isEmpty()){return;}
                    
                    
                    Class<?> TagClass = XposedHelpers.findClass("com.bilibili.pegasus.api.modelv2.Tag",lpparam.classLoader);
                    Field textField = TagClass.getField("text");
                    Class<?> ArgsClass = XposedHelpers.findClass("com.bilibili.pegasus.api.modelv2.Args",lpparam.classLoader);
                    Class<?> DescButtonClass = XposedHelpers.findClass("com.bilibili.pegasus.api.modelv2.DescButton",lpparam.classLoader);
                    Field upIdField = XposedHelpers.findField(ArgsClass,"upId");
                    Field upNameField = XposedHelpers.findField(ArgsClass,"upName");
                    Class<?> storyCardIconClass = XposedHelpers.findClass("com.bilibili.app.comm.list.common.data.StoryCardIcon",lpparam.classLoader);
                    
                    
                
                    HashMap<Class,Boolean> PushCardClassRecord = new HashMap<>();
                    
                    for (int i = list.size()-1; i >= 0; i--) {
                        //log(list.get(i));
                        Object BasicIndexItem = list.get(i);
                        Class<?> clazz = BasicIndexItem.getClass();
                        //log(clazz);
                        String ClassPath = clazz.getName();
                        
                        if(!PushCardClassRecord.containsKey(clazz)){
                          
                            PushCardClassRecord.put(clazz,containField(clazz,"rcmdReason"));
                        }
                        
                        if(PushCardClassRecord.get(clazz)){
                        
                            Field rcmdReasonField = clazz.getField("rcmdReason");
                            Object rcmdReason = rcmdReasonField.get(list.get(i));
                                if(rcmdReason!=null){
                                String text = (String) textField.get(rcmdReason);
                                //log(text);
                                if(text.contains("点赞")&&sharedPreferences.getBoolean("HomePagePushRemoveVideoLikeCount",false)){
                                    rcmdReasonField.set(BasicIndexItem,null);
                                    Field argsField = XposedHelpers.findField(clazz,"args");

                                    Object args = argsField.get(BasicIndexItem);
                                    Long upId = (Long) upIdField.get(args);
                                    String upName = (String) upNameField.get(args);

                                    Object DescButton = DescButtonClass.getConstructor().newInstance();
                                    XposedHelpers.findField(DescButtonClass,"event").set(DescButton,"nickname");
                                    XposedHelpers.findField(DescButtonClass,"isFollow").set(DescButton,0);
                                    XposedHelpers.findField(DescButtonClass,"isFollowed").set(DescButton,0);
                                    XposedHelpers.findField(DescButtonClass,"selected").set(DescButton,0);
                                    XposedHelpers.findField(DescButtonClass,"text").set(DescButton,upName);
                                    XposedHelpers.findField(DescButtonClass,"type").set(DescButton,1);
                                    XposedHelpers.findField(DescButtonClass,"uri").set(DescButton,"bilibili://space/"+upId);

                                    Field descButtonField =XposedHelpers.findField(clazz,"descButton");
                                    descButtonField.set(BasicIndexItem,DescButton);
                                
                                }
                                if(text.contains("竖屏")&&sharedPreferences.getBoolean("HomePagePushTransformVerticalVideo",false)){
                                    rcmdReasonField.set(BasicIndexItem,null);
                                    Field goToField = XposedHelpers.findField(clazz,"goTo");
                                    goToField.set(BasicIndexItem,"av");
                                    Field gotoTypeField = XposedHelpers.findField(clazz,"gotoType");
                                    gotoTypeField.set(BasicIndexItem,3125);
                                    //bilibili://video/ uri是决定变量
                                    Field uriField = XposedHelpers.findField(clazz,"uri");
                                    uriField.set(BasicIndexItem,((String)(uriField.get(BasicIndexItem))).replace("story","video"));
                                    Field talkBackField = XposedHelpers.findField(clazz,"talkBack");
                                    talkBackField.set(BasicIndexItem,((String)(uriField.get(BasicIndexItem))).replace("竖屏","").replace("竖版",""));
                                    
                                    
                                    //log(BasicIndexItem.toString());
                                    
                                    
                                }
                                
                                if(sharedPreferences.getBoolean("HomePagePushRemoveVideoLikeCount",false)||sharedPreferences.getBoolean("HomePagePushTransformVerticalVideo",false)){
                                    Object storyCardIcon = storyCardIconClass.getConstructor().newInstance();
                                    XposedHelpers.findField(storyCardIconClass,"iconHeight").set(storyCardIcon,16);
                                    XposedHelpers.findField(storyCardIconClass,"iconNightUrl").set(storyCardIcon,"https://i0.hdslb.com/bfs/activity-plat/static/20230227/0977767b2e79d8ad0a36a731068a83d7/ldbCXtkoK2.png");
                                    XposedHelpers.findField(storyCardIconClass,"iconUrl").set(storyCardIcon,"https://i0.hdslb.com/bfs/activity-plat/static/20230227/0977767b2e79d8ad0a36a731068a83d7/077GOeHOfO.png");
                                    XposedHelpers.findField(storyCardIconClass,"iconWidth").set(storyCardIcon,16);
                                    Field storyCardIconField = XposedHelpers.findField(clazz,"storyCardIcon");
                                    storyCardIconField.set(BasicIndexItem,storyCardIcon);
                                }
                            }
                            
                        }
                        
                        if(sharedPreferences.getBoolean("HomePagePushFilterateAD",false)&&ClassPath.contains("Ad")){
                            //广告
                            list.remove(i);
                            //log("去广告");
                            continue;
                        }
                        if(sharedPreferences.getBoolean("HomePagePushFilterateBanner",false)&&(!ClassPath.contains("Item"))){
                            //横幅
                            list.remove(i);
                            //log("去横幅");
                            continue;
                        }
                        //正常视频 包含竖屏
                        
                        //log(rcmdReason.get(list.get(i)));
                        //rcmdReason.set(list.get(i),null);
                    }
                    //list.remove(0);
                    //param.args[0]=list;
                }
        });
    }
    
    
    public void RemoveVideoDetailPageAD(final XC_LoadPackage.LoadPackageParam lpparam)throws Throwable{
        if(!CheckSharedPreferences()){return;}
        if(!sharedPreferences.getBoolean("VideoDetailPageRemoveAD",false)){return;}
     
        //Lcom/bilibili/ship/theseus/detail/UnitedBizDetailsActivity;->onCreate(Landroid/os/Bundle;)V
        XposedHelpers.findAndHookMethod("com.bilibili.ship.theseus.detail.UnitedBizDetailsActivity",lpparam.classLoader,"onCreate",Bundle.class,new XC_MethodHook(){
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    Activity UnitedBizDetailsActivity = (Activity) param.thisObject;
                    
                    UnitedBizDetailsActivity.findViewById(UnitedBizDetailsActivity.getResources().getIdentifier("underplayer_container","id",TargetPackageName)).setVisibility(View.GONE);

                    //log("隐藏up主推荐");
                }
            });
       //Lcom/bilibili/app/comment3/ui/holder/CommentMetaDataTypeEnum$4;->invoke(Landroid/view/ViewGroup;)Lcom/bilibili/app/comment3/ui/holder/a;
        Class<?> CommentMetaDataTypeEnum$4Class = XposedHelpers.findClass("com.bilibili.app.comment3.ui.holder.CommentMetaDataTypeEnum$4",lpparam.classLoader);
        Method invokeMethod = CommentMetaDataTypeEnum$4Class.getMethod("invoke",ViewGroup.class);
        Class<?> holderAClass = invokeMethod.getReturnType();
        final Field ADFrameLayoutField = holderAClass.getDeclaredFields()[0];
        ADFrameLayoutField.setAccessible(true);
       //Lcom/bilibili/app/comment3/ui/holder/a;-><init>(Landroid/view/ViewGroup;)V
        XposedHelpers.findAndHookConstructor(holderAClass, ViewGroup.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    View ADView = (View) ADFrameLayoutField.get(param.thisObject);
                    //XposedBridge.log("ADViewID 0x"+Integer.toHexString( ADView.getId()));
                    //ADView.findViewById(0x7f090843).performClick();
                    //XposedBridge.log("隐藏黄条");
                }
            });
    }
    
    public void ManageVideoDetailPagePush(final XC_LoadPackage.LoadPackageParam lpparam) throws Exception{
        if(!CheckSharedPreferences()){return;}
        if(!sharedPreferences.getBoolean("VideoDetailPagePushRemoveVideoLikeCount",false)&&!sharedPreferences.getBoolean("VideoDetailPagePushFilterateNotAV",false)){return;}
        //这里的类有混淆 所以使用一些没有混淆的类作为跳板获取它们的class对象
        Class<?> DetailRelateServiceClass = XposedHelpers.findClass("com.bilibili.ship.theseus.united.page.intro.module.relate.DetailRelateService",lpparam.classLoader);
        //public DetailRelateService(@NotNull CoroutineScope coroutineScope, @NotNull Context context, @NotNull ComponentActivity componentActivity, @NotNull a aVar, @NotNull ActivityColorRepository activityColorRepository, @NotNull e eVar, @NotNull com.bilibili.ship.theseus.united.page.intent.a aVar2, @NotNull TheseusCastScreenRepository theseusCastScreenRepository, @NotNull PageReportService pageReportService, @NotNull dagger.a<IntroRecycleViewService> aVar3, @NotNull com.bilibili.ship.theseus.united.di.driver.a aVar4, @NotNull TheseusFloatLayerService theseusFloatLayerService) 
        Class<?> RelateEClass = DetailRelateServiceClass.getConstructors()[0].getParameterTypes()[5];
        //Lcom/bilibili/ship/theseus/united/page/intro/module/relate/e;
        //log("RelateEClass"+RelateEClass);
        Method RelateEDMethod = selectMethod(RelateEClass,List.class);
        //Lcom/bilibili/ship/theseus/united/page/intro/module/relate/e;->d()Ljava/util/List;
        //log("RelateEDMethod"+RelateEDMethod.getName());

        Class<?> DetailRelateService$createAvComponent$contract$1Class = XposedHelpers.findClass("com.bilibili.ship.theseus.united.page.intro.module.relate.DetailRelateService$createAvComponent$contract$1",lpparam.classLoader);
        //DetailRelateService$createAvComponent$contract$1(Ref.ObjectRef<RelateAvComponent.a.a> objectRef, v vVar, r rVar, a aVar, DetailRelateService detailRelateService, w wVar, Ref.ObjectRef<RelateAvComponent> objectRef2) 
        Class<?> RelateAvCardClass = DetailRelateService$createAvComponent$contract$1Class.getDeclaredConstructors()[0].getParameterTypes()[2];
        //Lcom/bilibili/ship/theseus/united/page/intro/module/relate/r;
        //log("RelateAvCardClass"+RelateAvCardClass);

        //DetailRelateService$createAIComponent$contract$1(Ref.ObjectRef<RelateAvComponent.a.a> objectRef, v vVar, q qVar, a aVar, DetailRelateService detailRelateService, w wVar, Ref.ObjectRef<RelateAvComponent> objectRef2) 
        //Class<?> DetailRelateService$createAIComponent$contract$1Class = XposedHelpers.findClass("com.bilibili.ship.theseus.united.page.intro.module.relate.DetailRelateService$createAIComponent$contract$1",lpparam.classLoader);
        Class<?> RelateCardClass = DetailRelateService$createAvComponent$contract$1Class.getDeclaredConstructors()[0].getParameterTypes()[1];
        //Lcom/bilibili/ship/theseus/united/page/intro/module/relate/v;
        //log("RelateCardClass"+RelateCardClass);
        //Field 
        final Field avCardField = selectField(RelateCardClass,RelateAvCardClass);
        avCardField.setAccessible(true);
        Class<?> RelatedCheeseComponent$aClass = XposedHelpers.findClass("com.bilibili.ship.theseus.united.page.intro.module.relate.cheese.RelatedCheeseComponent$a",lpparam.classLoader);
        //public RelatedCheeseComponent$a(@NotNull String str, @NotNull String str2, @NotNull String str3, @NotNull String str4, @NotNull StatInfoData statInfoData, @NotNull String str5, @NotNull String str6, boolean z, @Nullable a aVar, @Nullable a aVar2, boolean z2, @NotNull RelatedCheeseComponent.b bVar, boolean z3)
        Class<?> BadgeInfoClass = RelatedCheeseComponent$aClass.getDeclaredConstructors()[0].getParameterTypes()[8];
        //Lcom/bilibili/ship/theseus/united/page/intro/module/relate/a;
        //log("BadgeInfoClass "+BadgeInfoClass);
        final Field rcmdReasonField = selectField(RelateAvCardClass,BadgeInfoClass);

        rcmdReasonField.setAccessible(true);
        
        Class<?> RelateCardTypeClass = XposedHelpers.findClass("com.bilibili.ship.theseus.united.page.intro.module.relate.RelateCardType",lpparam.classLoader);
        final Field RelateCardTypeField =selectField(RelateCardClass,RelateCardTypeClass);
        RelateCardTypeField.setAccessible(true);
        Field avField = RelateCardTypeClass.getField("AV");
        final Object avType = avField.get(null);
     
        XposedBridge.hookMethod(RelateEDMethod,new XC_MethodHook(){
                @Override
                protected void afterHookedMethod(MethodHookParam param)throws Exception{

                    List VideoList = (List) param.getResult();
                    if(VideoList==null||VideoList.isEmpty()){return;}
                    for(int i = VideoList.size()-1; i >= 0; i--){
                        Object Card = VideoList.get(i);
                        if(Card==null){continue;}
                        Object avCard = avCardField.get(Card);
                        
                        //检测推送的类型
                        if(!RelateCardTypeField.get(Card).equals(avType)&&sharedPreferences.getBoolean("VideoDetailPagePushFilterateNotAV",false)){
                            VideoList.remove(i);
                            //log("去除非AV");
                            continue;
                        }
                        
                        if(avCard==null){continue;}
                        //检测推送的rcmdReason附加标签
                        Object rcmdReason = rcmdReasonField.get(avCard);
                        //log(rcmdReason);
                        if(rcmdReason!=null&&sharedPreferences.getBoolean("VideoDetailPagePushRemoveVideoLikeCount",false)){
                            rcmdReasonField.set(avCard,null);
                            //log("rcmdReason设置为null");
                        }
                    }
                }
            });
        //Lcom/bilibili/ship/theseus/united/page/intro/module/relate/e;->d()Ljava/util/List;
        
    }
    
    public void testFunction(final XC_LoadPackage.LoadPackageParam lpparam)throws Throwable{
        //hookViewBinding(XposedHelpers.findClass("com.bilibili.ship.theseus.detail.databinding.b",lpparam.classLoader),MainActivityV2);
        //Lcom/bilibili/ship/theseus/detail/databinding/b;->bind(Landroid/view/View;)Lcom/bilibili/ship/theseus/detail/databinding/b;
        
    }
    
    
    public void getBLogMessage(final XC_LoadPackage.LoadPackageParam lpparam){
        //Ltv/danmaku/android/log/BLog;->i(Ljava/lang/String;Ljava/lang/String;)V
        XposedHelpers.findAndHookMethod("tv.danmaku.android.log.BLog",lpparam.classLoader,"i",String.class,String.class,new XC_MethodHook(){
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    String label = (String) param.args[0];
                    if(!label.contains("Detail")){return;}
                    log("BLog "+param.args[1]);
                }
        });
    }
    
    
    public Field selectField(Class<?> TargetClass,Class<?> FieldTypeClass){
        for(Field field:TargetClass.getDeclaredFields()){
            if(field.getType().equals(FieldTypeClass)){
                return field;
            }
        }
        return null;
    }
    
    public Method selectMethod(Class<?> TargetClass,Class<?> returnType,Class<?>... args){
        Method TargetMethod = null;
        //Class<?> TargetClass = XposedHelpers.findClass(ClassPath,classLoader);

        for(Method method :TargetClass.getDeclaredMethods()){
            //XposedBridge.log("method "+method.getName());
            //XposedBridge.log("返回值 "+method.getReturnType()+"和"+returnType);
            if (method.getReturnType().equals(returnType)) {
                //XposedBridge.log("返回类型正确");
                Class<?>[] argt = method.getParameterTypes();
                /*if (argt.length == 2 && argt[0].equals(int.class) && argt[1].equals(View.class)) {
                 TabSetMethod = method;
                 break;
                 }
                 */
                if(argt.length!=args.length){continue;}
                //XposedBridge.log("参数数目正确");
                boolean argsCheck = true;
                for (int i = 0; i < argt.length; i++) {
                    if(!argt[i].equals(args[i])){
                        //XposedBridge.log(i+"参数类型错误"+argt[i]+".equals("+args[i]+")");
                        argsCheck=false;
                        break;
                    }
                }

                if(!argsCheck){continue;}
                //XposedBridge.log("参数类型正确");
                TargetMethod=method;
            }
        }
        return TargetMethod;
    }
        
    
    
    public boolean containField(Class clazz,String variableName){
        
        for (Field field : clazz.getFields()) {
            
            if (field.getName().equals(variableName)) {
                return true;
                
            }
        }
        return false;
    }
    
    public boolean CheckSharedPreferences(){
        if(MainActivityV2==null){return false;}
        if(sharedPreferences==null){
            sharedPreferences = MainActivityV2.getSharedPreferences("FunctionPrefs", Context.MODE_PRIVATE);
        }
        return true;
    }
    
    public void hookViewBinding(final Class<?> ViewBindingClass,Context context)throws Throwable{
        final List<Field> ViewList = new ArrayList<>();
        for(Field field:ViewBindingClass.getDeclaredFields()){
            //if(field.getType()){}
            Class<?> TypeClass = field.getType();
            Constructor selectedConstructor=null;
            try {
                selectedConstructor = TypeClass.getDeclaredConstructor(Context.class);
            } catch (NoSuchMethodException e) {
                continue;
            } 
            if(selectedConstructor==null){continue;}
            // 使用选定的构造函数和参数列表创建对象
            Object object = selectedConstructor.newInstance(context);
            
            
            if(object instanceof View){
                field.setAccessible(true);
                ViewList.add(field);
            }
            
        }
        XposedBridge.hookAllConstructors(ViewBindingClass,new XC_MethodHook(){
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    XposedBridge.log("hookViewBinding "+ViewBindingClass);
                    for (int i = 0; i < ViewList.size(); i++) {
                        //if(param.thisObject==null){return;}
                        Field field = ViewList.get(i);
                        View view = (View) field.get(param.thisObject);
                        XposedBridge.log("hookViewBinding Name:"+field.getName()+" Id:0x"+Integer.toHexString(view.getId())+" Type:"+view.getClass());
                    }
                }
        });
        
    }
    
    public int getViewID(String id){
        return MainActivityV2.getResources().getIdentifier(id,"id",TargetPackageName);
    }
}
